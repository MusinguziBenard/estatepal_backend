const crypto = require('crypto');

function sha256(text) {
  return crypto.createHash('sha256').update(text).digest('hex');
}

function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

/** 6-digit numeric OTP */
function generateOtp() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function reference(prefix, seq) {
  const n = String(seq).padStart(6, '0');
  const year = new Date().getFullYear();
  return `${prefix}-${year}-${n}`;
}

module.exports = { sha256, randomToken, generateOtp, reference };
