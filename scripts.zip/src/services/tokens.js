const { supabase } = require('../db/supabase');

/**
 * Collect Expo push tokens for given user ids.
 */
async function tokensForUsers(userIds) {
  if (!userIds?.length) return [];
  const { data: devices } = await supabase
    .from('devices')
    .select('push_token')
    .in('user_id', userIds);
  const fromDevices = (devices || []).map((d) => d.push_token);

  const { data: users } = await supabase
    .from('users')
    .select('push_tokens')
    .in('id', userIds);
  const fromUsers = (users || []).flatMap((u) => u.push_tokens || []);

  return [...new Set([...fromDevices, ...fromUsers].filter(Boolean))];
}

/** All registered tokens (for broadcast e.g. new published listing) */
async function allTokens() {
  const { data: devices } = await supabase.from('devices').select('push_token');
  return [...new Set((devices || []).map((d) => d.push_token).filter(Boolean))];
}

/** Admin user ids */
async function adminUserIds() {
  const { data } = await supabase.from('users').select('id').eq('role', 'admin');
  return (data || []).map((u) => u.id);
}

module.exports = { tokensForUsers, allTokens, adminUserIds };
