const { supabase } = require('../../db/supabase');
const config = require('../../config');
const { generateOtp, sha256, randomToken } = require('../../utils/crypto');
const { mapUser } = require('../../utils/mappers');
const { validation, unauthorized } = require('../../utils/errors');
const { emit, EVENTS } = require('../../events/bus');

const SESSION_DAYS = 60;

function normalizePhone(phone) {
  const p = String(phone || '').replace(/\s/g, '');
  if (!/^\+?\d{10,15}$/.test(p)) throw validation('Invalid phone number');
  return p.startsWith('+') ? p : `+${p}`;
}

async function requestOtp(phoneRaw) {
  const phone = normalizePhone(phoneRaw);
  const code = process.env.NODE_ENV === 'development' && process.env.DEV_OTP
    ? process.env.DEV_OTP
    : generateOtp();

  const expires = new Date(Date.now() + config.otpTtlMinutes * 60_000).toISOString();

  // Invalidate previous unused codes
  await supabase.from('otp_codes').update({ used: true }).eq('phone', phone).eq('used', false);

  const { error } = await supabase.from('otp_codes').insert({
    phone,
    code,
    expires_at: expires,
  });
  if (error) throw error;

  // Production: integrate SMS provider (Africa's Talking, Twilio, etc.)
  // For now log in non-production so demos work
  if (config.env !== 'production') {
    console.log(`[otp] ${phone} → ${code}`);
  } else {
    // TODO: await smsProvider.send(phone, `Your EstatePal code is ${code}`);
    console.log(`[otp] sent to ${phone}`);
  }

  return { ok: true };
}

async function verifyOtp(phoneRaw, code, acceptedTerms) {
  const phone = normalizePhone(phoneRaw);
  if (!code || String(code).length < 4) throw validation('Invalid code');

  const { data: rows, error } = await supabase
    .from('otp_codes')
    .select('*')
    .eq('phone', phone)
    .eq('used', false)
    .gte('expires_at', new Date().toISOString())
    .order('created_at', { ascending: false })
    .limit(1);

  if (error) throw error;
  const otp = rows?.[0];
  if (!otp || otp.code !== String(code).trim()) throw unauthorized('Wrong or expired code');

  await supabase.from('otp_codes').update({ used: true }).eq('id', otp.id);

  // Upsert user
  let { data: user } = await supabase.from('users').select('*').eq('phone', phone).maybeSingle();
  const isNew = !user;
  const isAdminPhone = config.adminPhones.includes(phone);

  if (!user) {
    const { data: created, error: cErr } = await supabase
      .from('users')
      .insert({
        phone,
        role: isAdminPhone ? 'admin' : 'user',
        accepted_terms_at: acceptedTerms ? new Date().toISOString() : null,
      })
      .select('*')
      .single();
    if (cErr) throw cErr;
    user = created;
  } else {
    const patch = {};
    if (acceptedTerms && !user.accepted_terms_at) patch.accepted_terms_at = new Date().toISOString();
    if (isAdminPhone && user.role !== 'admin') patch.role = 'admin';
    if (Object.keys(patch).length) {
      const { data: updated } = await supabase
        .from('users')
        .update(patch)
        .eq('id', user.id)
        .select('*')
        .single();
      user = updated || user;
    }
  }

  // Create session
  const rawToken = randomToken(32);
  const tokenHash = sha256(rawToken);
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400_000).toISOString();

  await supabase.from('sessions').insert({
    user_id: user.id,
    token_hash: tokenHash,
    expires_at: expiresAt,
  });

  emit(isNew ? EVENTS.USER_SIGNED_UP : EVENTS.USER_SIGNED_IN, {
    userId: user.id,
    phone: user.phone,
  });

  return { token: rawToken, user: mapUser(user) };
}

async function resolveSession(rawToken) {
  if (!rawToken) return null;
  const tokenHash = sha256(rawToken);
  const { data: session } = await supabase
    .from('sessions')
    .select('*, users(*)')
    .eq('token_hash', tokenHash)
    .gte('expires_at', new Date().toISOString())
    .maybeSingle();

  if (!session?.users) return null;
  return mapUser(session.users);
}

async function me(userId) {
  const { data } = await supabase.from('users').select('*').eq('id', userId).single();
  return mapUser(data);
}

async function revokeSession(rawToken) {
  if (!rawToken) return;
  await supabase.from('sessions').delete().eq('token_hash', sha256(rawToken));
}

module.exports = {
  requestOtp,
  verifyOtp,
  resolveSession,
  me,
  revokeSession,
  normalizePhone,
};
