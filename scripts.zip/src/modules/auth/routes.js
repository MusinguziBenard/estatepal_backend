const { Router } = require('express');
const { z } = require('zod');
const { asyncHandler } = require('../../utils/errors');
const { validate } = require('../../middleware/validate');
const { requireAuth } = require('../../middleware/auth');
const auth = require('./service');

const router = Router();

router.post(
  '/otp',
  validate(z.object({ phone: z.string().min(10) })),
  asyncHandler(async (req, res) => {
    await auth.requestOtp(req.body.phone);
    res.status(204).end();
  })
);

router.post(
  '/verify',
  validate(
    z.object({
      phone: z.string().min(10),
      code: z.string().min(4),
      acceptedTerms: z.boolean().optional().default(true),
    })
  ),
  asyncHandler(async (req, res) => {
    const result = await auth.verifyOtp(req.body.phone, req.body.code, req.body.acceptedTerms);
    res.json(result);
  })
);

router.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await auth.me(req.user.id);
    res.json(user);
  })
);

// Alias used by frontend: GET /me
router.get(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await auth.me(req.user.id);
    res.json(user);
  })
);

module.exports = router;
