const { Router } = require('express');
const { asyncHandler } = require('../../utils/errors');
const { requireAuth } = require('../../middleware/auth');
const listings = require('../listings/service');
const connections = require('../connections/service');
const auth = require('../auth/service');

const router = Router();

router.get(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    res.json(await auth.me(req.user.id));
  })
);

router.get(
  '/listings',
  requireAuth,
  asyncHandler(async (req, res) => {
    res.json(await listings.mine(req.user.id));
  })
);

router.get(
  '/saved',
  requireAuth,
  asyncHandler(async (req, res) => {
    res.json(await listings.saved(req.user.id));
  })
);

router.get(
  '/connections',
  requireAuth,
  asyncHandler(async (req, res) => {
    res.json(await connections.mine(req.user.id));
  })
);

router.get(
  '/connections/received',
  requireAuth,
  asyncHandler(async (req, res) => {
    res.json(await connections.received(req.user.id, req.query.listingId));
  })
);

module.exports = router;
